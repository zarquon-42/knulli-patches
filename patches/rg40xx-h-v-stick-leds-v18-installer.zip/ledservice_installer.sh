#!/bin/sh

SERVICES_KEY="system.services"
LED_SERVICE_NAME="analog_stick_led"
PATCHES_DIR="./patches"

if [ ! -d "$PATCHES_DIR" ]; then
    echo "Directory $PATCHES_DIR does not exist"
    exit 1
elif [ -z "$(ls -A "$PATCHES_DIR")" ]; then
    echo "Directory $PATCHES_DIR is empty"
    exit 1
fi

# Format: "filename target_directory executable"
FILES_AND_TARGETS="
analog_stick_led_daemon.sh /usr/bin/ true
analog_stick_led.sh /usr/bin/ true
analog_stick_led /usr/share/batocera/services/ true
99-postresume-jsled /etc/pm/sleep.d/ true
led.sh /usr/share/emulationstation/scripts/achievements/ true
call_achievements_hooks.sh /usr/share/batocera/configgen/ true
"

echo "$FILES_AND_TARGETS" | while IFS=" " read -r FILE TARGET_DIR EXECUTABLE; do
    # Skip empty lines
    if [ -z "$FILE" ]; then
        continue
    fi
    
    SOURCE_FILE="${PATCHES_DIR}/${FILE}"
    
    if [ -f "$SOURCE_FILE" ]; then
        mkdir -p "$TARGET_DIR"
        
        mv "$SOURCE_FILE" "$TARGET_DIR"
        
        if [ "$EXECUTABLE" = "true" ]; then
            chmod +x "${TARGET_DIR}/${FILE}"
        fi
        
        echo "Moved $FILE to $TARGET_DIR and set executable: $EXECUTABLE"
    else
        echo "File $SOURCE_FILE does not exist"
    fi
    
done

# Enable service in batocera.conf to be turned on after next reboot (unless it was already enabled)
SERVICES=$(batocera-settings-get $SERVICES_KEY)
if echo "$SERVICES" | grep -iq "$LED_SERVICE_NAME";then
    echo "Service $LED_SERVICE_NAME is already enabled."
else
   if [ -z "$SERVICES" ]; then
        SERVICES=$LED_SERVICE_NAME
    else
        SERVICES="$SERVICES $LED_SERVICE_NAME"
    fi
    batocera-settings-set $SERVICES_KEY "$SERVICES"
    echo "Enabled service $LED_SERVICE_NAME."
fi

if [ -f "/userdata/system/configs/emulationstation/scripts/achievements/led.sh" ]; then
  rm "/userdata/system/configs/emulationstation/scripts/achievements/led.sh"
  echo "Removed old LED script from userdata folder."
fi

# Save overlay to persist changes
batocera-save-overlay

echo "Rebooting..."
sleep 1
reboot

exit 0
